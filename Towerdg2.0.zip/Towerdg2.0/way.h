#ifndef way_H
#define way_H
#include <QPoint>
#include <QPainter>

class Way
{
public:
    Way(QPoint pos);
    void setNextPoint(Way *nextPoint);//设定下一个目的点
    Way* nextPoint();
    QPoint position();//位置点

private:
    QPoint Nowpos;//当前位置
    Way* NextPoint;//下一个点
};


#endif // way_H
