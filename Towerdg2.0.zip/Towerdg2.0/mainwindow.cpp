#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"QPainter"
#include"way.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::paintEvent(QPaintEvent*){

    QPixmap map(":/image/map.png");
    QPainter painter(this);
    painter.drawPixmap(0,0,map);
}

void MainWindow::addPoints()
{
    Way* Point1 = new Way(QPoint(900, 675));
    PointsList.push_back(Point1);

    Way* Point2 = new Way(QPoint(863, 675));
    PointsList.push_back(Point2);
    Point2->setNextPoint(Point1);

    Way* Point3 = new Way(QPoint(863, 160));
    PointsList.push_back(Point3);
    Point3->setNextPoint(Point2);

    Way* Point4 = new Way(QPoint(417, 160));
    PointsList.push_back(Point4);
    Point4->setNextPoint(Point3);

    Way* Point5 = new Way(QPoint(417, 545));
    PointsList.push_back(Point5);
    Point5->setNextPoint(Point4);

    Way* Point6 = new Way(QPoint(160, 545));
    PointsList.push_back(Point6);
    Point6->setNextPoint(Point5);

    Way* Point7 = new Way(QPoint(160, 231));
    PointsList.push_back(Point7);
    Point7->setNextPoint(Point6);

    Way* Point8 = new Way(QPoint(35, 231));
    PointsList.push_back(Point8);
    Point8->setNextPoint(Point7);
}
