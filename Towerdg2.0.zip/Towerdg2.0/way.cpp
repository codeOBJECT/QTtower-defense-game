#include "way.h"

Way::Way(QPoint pos): Nowpos(pos),NextPoint(NULL)
{

}

void Way::setNextPoint(Way* _nextPoint)
{
    NextPoint = _nextPoint;
}

Way* Way::nextPoint()
{
    return NextPoint;
}

QPoint Way::position()
{
    return Nowpos;
}
